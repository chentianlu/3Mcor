####代謝物-微生物聚类相关分析
####输入数据：1.代谢物数据.csv，行为样本名，列为代谢物变量；
####          2.16sOTU数据.csv,行为样本名，列为菌变量；
####          3.表型数据.csv，行为样本名，列为表型数据；
####输出数据：1.代谢物聚类数据，即降维后的新代谢物模块数据；
####          2.微生物聚类数据，即降维后的新微生物模块数据；
####          3.代谢物原始数据的计算结果，包含每一代谢物所属的代谢物模块，与该模块的相关性（KME）,在该模块内的连通性或重要性（KIN），与表性的相关性（r,p,fdr）;
####          4.微生物原始数据的计算结果，包含每一微生物所属的微生物模块，与该模块的相关性（KME）,在该模块内的连通性或重要性（KIN），与表性的相关性（r,p,fdr）;
####          5.代谢物模块与表型的相关性结果；
####          6.微生物模块与表型的相关性结果；
####          7.微生物模块与代谢物模块之间的相关性结果；
####          8.代谢物模块与微生物模块与表型的相关性热图。


### Step 1 - Set working directory
setwd ("./top")



# step2_load.libraries.R


#library (xlsx) ### Saving to spreadsheet
#library (data.table) ### Fast read of large files into R
library (WGCNA) ### -	Clustering software. Previously reported work done using v1.34
library (flashClust) ### Clustering software
library (ppcor) ### Partial Spearman correlations, for confounder analysis. Previously reported work done using v1.0
library (gplots) ### Plotting
library (cowplot) ### Plotting; to arrange several plots on the same page
library (ggplot2) ### Plotting
library (plyr) ### Data transformations



### Step 3 - Import input files
options (stringsAsFactors = FALSE)

### - phenotypes
phenotypes = read.csv (file = "./data/phenotypes.csv", row.names = 1, header = T, sep = ",")

### - metabolites
metabolites = read.csv (file = "./data/metabolites.csv", row.names = 1, header = T, sep = ",")

### - cluster_mapping_file_m
#cluster_mapping_file_m = read.csv (file = "./data/cluster_mapping_file_m.csv", header = T, sep = ",", row.names = 1)
#cluster_mapping_file_m$label =  sapply (rownames (cluster_mapping_file_m),  function (x) paste (cluster_mapping_file_m [x, "New_Name"], cluster_mapping_file_m [x, "Description"], sep = ": "))



### Step 5 - Identify clusters of metabolites

###Settings for WGCNA generally
cor_method          = "spearman" ### for association with clinical parameters
corFun_tmp          = "bicor"
cluster_method      = "average"
corOptions_list     = list (use = 'pairwise.complete.obs') 
corOptions_str      = "use = 'pairwise.complete.obs'"
BH_pval_asso_cutoff = 0.05
NetworkType         = "signed" ### Signed-network (as the PC1 and median profile does not make sense as a summary measure of a cluster with anticorrelated metabolites.)

###Specify data and parameters 
dat_tmp = log2 (metabolites) ### work in logarithmic space

### Settings for WGCNA on metabolites measurements
### Once these are established the steps below can be run
RsquareCut_val      = 0.89 ### usually ranges 0.80-0.95 but requires inspecting curves
mergingThresh       = 0.20 ### Maximum dissimilarity of module eigengenes (i.e. 1-correlation) for merging modules.
minModuleSize       = 3 ### minimum number of metabolites constituting a cluster
SoftPower           = 13 ### beta-value, main parameter to optimize

### Calculate weighted adjacency matrix
A = adjacency (dat_tmp, power = SoftPower, type = NetworkType, corFnc = corFun_tmp, corOptions = corOptions_str)
colnames (A) = rownames (A) = colnames (dat_tmp)
### Define dissimilarity based on topological overlap
dissTOM = TOMdist (A, TOMType = NetworkType)
colnames (dissTOM) = rownames (dissTOM) = colnames (dat_tmp)
### Hierarchical clustering
metaTree = flashClust (as.dist (dissTOM), method = cluster_method)
### Define modules by cutting branches
moduleLabels1 = cutreeDynamic (dendro = metaTree, distM = dissTOM, method = "hybrid", deepSplit = 4, pamRespectsDendro = T, minClusterSize = minModuleSize)
moduleLabels1 = labels2colors (moduleLabels1)
### Automatically merge highly correlated modules
merge = mergeCloseModules (dat_tmp, moduleLabels1, corFnc = corFun_tmp, corOptions = corOptions_list, cutHeight = mergingThresh)
### Determine resulting merged module colors
moduleLabels2 = merge$colors
### Establish eigengenes of the newly merged modules, used for cluster overall abundances
MEs = merge$newMEs
### Choose final module assignments
moduleColorsMeta = moduleLabels2
names (moduleColorsMeta) = colnames (dat_tmp)
MEsMeta = orderMEs (MEs)
rownames (MEsMeta) = rownames (dat_tmp)

##创建cluster_mapping_file文件
cluster_mapping_file_m <- data.frame(New_Name=paste0("M",1:length(MEsMeta)),Description=c("None"))
row.names(cluster_mapping_file_m) <- paste0("M_",colnames(MEsMeta))
cluster_mapping_file_m$label =  sapply (rownames (cluster_mapping_file_m),  function (x) paste (cluster_mapping_file_m [x, "New_Name"], cluster_mapping_file_m [x, "Description"], sep = ": "))


### Determine relevant descriptive statistics of established clusters
### kIN: within-module connectivity, determined by summing connectivity with all
###      other metabolites in the given cluster.
### kME: bicor-correlation between the metabolite profile and module eigenvector; 
### both measures of intramodular hub-metabolite status.
kIN <-      vector (length = ncol (dat_tmp)); names (kIN) = colnames (dat_tmp)
kME <-      vector (length = ncol (dat_tmp)); names (kME) = colnames (dat_tmp)
modules <-  vector (length = ncol (dat_tmp)); names (modules) = colnames (dat_tmp)

for (module in names (table (moduleColorsMeta))) {   
  
  all.metabolites = names (dat_tmp)
  inModule = (moduleColorsMeta == module)
  module.metabolites = names (moduleColorsMeta [inModule])
  modules [module.metabolites] = module 
  kIN [module.metabolites] = sapply (module.metabolites, function (x) sum (A [x, module.metabolites]) - 1)
  datKME = signedKME (dat_tmp, MEsMeta, corFnc = corFun_tmp, corOptions = corOptions_str)
  rownames (datKME) = colnames (dat_tmp)
  kME [module.metabolites] = datKME [module.metabolites, paste ("kME", module, sep = "")]   
  
}
output = data.frame ("module" = modules, "kME" = kME, "kIN" = kIN,"cluster_name" = sapply (modules, function (m) cluster_mapping_file_m [paste0 ("M_ME", m), "New_Name"]))



### Step 6 - Link individual metabolite to phenotype of interest
tmpMat = array (NA, c (ncol (metabolites), 1, 2))
dimnames (tmpMat) [[1]] = colnames (metabolites)
dimnames (tmpMat) [[2]] = c ("age")
dimnames (tmpMat) [[3]] = c ("estimate", "p.value")

### Associating individual metabolites with age
tmpMat [, "age", c ("estimate", "p.value")] =
  t (apply (metabolites, MARGIN = 2, FUN = function (x)
    unlist (cor.test (phenotypes$age, x,
                      method = cor_method, use = "pairwise.complete.obs")[c ("estimate", "p.value")])))
#tmpMat

### Sort by cluster_name and then decreasing values of kIN
output2 = cbind(tmpMat[, "age", c ("estimate", "p.value")], "p.adjust" = p.adjust (tmpMat [, "age", "p.value"], method = "BH"))
colnames (output2) = paste (rep ("age", 3), colnames (output2), sep = "_")
output3 = cbind (output, output2)
output3 = output3 [with (output3,  order (cluster_name, -kIN)), ]

### Write to file
write.table (output3, file = "./result/individual_metabolites.txt", sep = "\t", col.names = NA, quote = F, row.names = T)
rm (output, output2, output3, tmpMat, dat_tmp)


# step7_合并结果
### Create a joint data frame of metabolite cluster eigengene
### equivalents/effective abundances ('MEsMetLip')
MEsMetLip = MEsMeta [rownames (MEsMeta),]
### Rename module names (columnames) from 'colors' to numbers
colnames (MEsMetLip) = cluster_mapping_file_m [paste0 ("M_", colnames (MEsMeta)), "New_Name"]

### Save MEsMetLip to file, order by module number
write.table (MEsMetLip [ , order (colnames (MEsMetLip))], file = "./result/MEs_metabolites_clusters.txt", sep = "\t", row.names = T, col.names = NA, quote = F)



### Step 8 - Link metabolite clusters to phenotype of interest
### Analogous to Step 6.
### This is a core analysis step generating associations between the
### integrated/clustered –omics data and a clinically interesting phenotype.
cor_age <- list () ### Data structure for storing results of correlation tests under different setups

tmpMat = array (NA, c (ncol (MEsMetLip), 1, 2))
dimnames (tmpMat) [[1]] = names (MEsMetLip)
dimnames (tmpMat) [[2]] = c ("age") 
dimnames (tmpMat) [[3]] = c ("estimate", "p.value")

### Associating metabolite clusters with age     
tmpMat [, "age", c ("estimate", "p.value")] =
  t (apply (MEsMetLip, MARGIN = 2, FUN = function (x) 
    unlist (cor.test (phenotypes$age, x,
                      method = cor_method, use = "pairwise.complete.obs") [c ("estimate", "p.value")])))       

cor_age [["metlip"]] <- tmpMat
rm (tmpMat)



### Step 11 - Save phenotype associations
###
### Save the age association of metabolite clusters calculated in Step 8.
###
tmpMat = cor_age [["metlip"]]
out = cbind (tmpMat [, "age", c("estimate", "p.value")], "p.adjust" = p.adjust (tmpMat [, "age","p.value"], method = "BH"))
colnames (out) = paste (rep ("age", 3), colnames (out), sep = "_")
write.table (out, file = "./result/age_cluster_metabolites.txt", sep = "\t", row.names = T, col.names = NA, quote = F)



### Step 12 - Select features with significant differences
###
### Here, combine and integrate those functional, taxonomic and metabolomics
### features which reliably correspond to the host phenotype of interest, then
### later determine their inter-correlations.
### 此处只计算metabolomics features中P.adjust < 0.1的

final.fdr.cutoffs = 0.1 ### FDR thresholds, change to your likings.
sig_name <- list ()
sig_name [[paste ("fdr", final.fdr.cutoffs, sep = "_")]] [["metlip"]] =
  names (which (p.adjust (tmpMat [ , "age", "p.value"], method = "BH") < final.fdr.cutoffs))

#sig_name

# 将具有显著性的metabolites cluster提取出来
sig_name_metabolites <- row.names(out)[out[,3] < 0.1]
MEsmeta_sig <- MEsMetLip[,sig_name_metabolites]



##############################################################################################
##############################################################################################
###以相同的方法计算菌群数据
### -phenotypes
#phenotypes = read.csv (file = "./data/phenotypes.csv", row.names = 1, header = T, sep = ",")

### -bacteria
# 数据转换
data <- read.csv("./data/bacteria_0.csv",header = T, row.names = 1,sep = ",")
data1 <- data *500000
#head(data1)
data1[data1==0] = 1.0000001   #将0 转换为1.0000001
write.csv(data1,"./data/bacteria.csv")
rm(data,data1)
bacteria = read.csv (file = "./data/bacteria.csv", row.names = 1, header = T, sep = ",")

### - cluster_mapping_file_b
#cluster_mapping_file_b = read.csv (file = "./data/cluster_mapping_file_b.csv", header = T, sep = ",", row.names = 1)
#cluster_mapping_file_b$label =  sapply (rownames (cluster_mapping_file_b),  function (x) paste (cluster_mapping_file_b [x, "New_Name"], cluster_mapping_file_b [x, "Description"], sep = ": "))



### Step 5 - Identify clusters bacteria

###Settings for WGCNA generally
cor_method          = "spearman" ### for association with clinical parameters
corFun_tmp          = "bicor"
cluster_method      = "average"
corOptions_list     = list (use = 'pairwise.complete.obs') 
corOptions_str      = "use = 'pairwise.complete.obs'"
BH_pval_asso_cutoff = 0.05
NetworkType         = "signed" ### Signed-network (as the PC1 and median profile does not make sense as a summary measure of a cluster with anticorrelated metabolites.)

###Specify data and parameters 
dat_tmp = log2 (bacteria) ### work in logarithmic space

### Settings for WGCNA on bacteria measurements
### Once these are established the steps below can be run
RsquareCut_val      = 0.89 ### usually ranges 0.80-0.95 but requires inspecting curves
mergingThresh       = 0.20 ### Maximum dissimilarity of module eigengenes (i.e. 1-correlation) for merging modules.
minModuleSize       = 3 ### minimum number of metabolites constituting a cluster
SoftPower           = 13 ### beta-value, main parameter to optimize

### Calculate weighted adjacency matrix
A = adjacency (dat_tmp, power = SoftPower, type = NetworkType, corFnc = corFun_tmp, corOptions = corOptions_str)
colnames (A) = rownames (A) = colnames (dat_tmp)
### Define dissimilarity based on topological overlap
dissTOM = TOMdist (A, TOMType = NetworkType)
colnames (dissTOM) = rownames (dissTOM) = colnames (dat_tmp)
### Hierarchical clustering
metaTree = flashClust (as.dist (dissTOM), method = cluster_method)
### Define modules by cutting branches
moduleLabels1 = cutreeDynamic (dendro = metaTree, distM = dissTOM, method = "hybrid", deepSplit = 4, pamRespectsDendro = T, minClusterSize = minModuleSize)
moduleLabels1 = labels2colors (moduleLabels1)
### Automatically merge highly correlated modules
merge = mergeCloseModules (dat_tmp, moduleLabels1, corFnc = corFun_tmp, corOptions = corOptions_list, cutHeight = mergingThresh)
### Determine resulting merged module colors
moduleLabels2 = merge$colors
### Establish eigengenes of the newly merged modules, used for cluster overall abundances
MEs = merge$newMEs
### Choose final module assignments
moduleColorsMeta = moduleLabels2
names (moduleColorsMeta) = colnames (dat_tmp)
MEsMeta = orderMEs (MEs)
rownames (MEsMeta) = rownames (dat_tmp)


###创建cluster_mapping_file_b
cluster_mapping_file_b <- data.frame(New_Name=paste0("L",1:length(MEsMeta)),Description="None")
row.names(cluster_mapping_file_b) <- paste0("L_",colnames(MEsMeta))
cluster_mapping_file_b$label =  sapply (rownames (cluster_mapping_file_b),  function (x) paste (cluster_mapping_file_b [x, "New_Name"], cluster_mapping_file_b [x, "Description"], sep = ": "))

### Determine relevant descriptive statistics of established clusters
### kIN: within-module connectivity, determined by summing connectivity with all
###      other metabolites in the given cluster.
### kME: bicor-correlation between the metabolite profile and module eigenvector; 
### both measures of intramodular hub-metabolite status.
kIN <-      vector (length = ncol (dat_tmp)); names (kIN) = colnames (dat_tmp)
kME <-      vector (length = ncol (dat_tmp)); names (kME) = colnames (dat_tmp)
modules <-  vector (length = ncol (dat_tmp)); names (modules) = colnames (dat_tmp)



for (module in names (table (moduleColorsMeta))) {   
  
  all.metabolites = names (dat_tmp)
  inModule = (moduleColorsMeta == module)
  module.metabolites = names (moduleColorsMeta [inModule])
  modules [module.metabolites] = module 
  kIN [module.metabolites] = sapply (module.metabolites, function (x) sum (A [x, module.metabolites]) - 1)
  datKME = signedKME (dat_tmp, MEsMeta, corFnc = corFun_tmp, corOptions = corOptions_str)
  rownames (datKME) = colnames (dat_tmp)
  kME [module.metabolites] = datKME [module.metabolites, paste ("kME", module, sep = "")]   
  
}

output = data.frame ("module" = modules, "kME" = kME, "kIN" = kIN,"cluster_name" = sapply (modules, function (m) cluster_mapping_file_b [paste0 ("L_ME", m), "New_Name"]))



### Step 6 - Link individual bacteria to phenotype of interest
tmpMat = array (NA, c (ncol (bacteria), 1, 2))
dimnames (tmpMat) [[1]] = colnames (bacteria)
dimnames (tmpMat) [[2]] = c ("age")
dimnames (tmpMat) [[3]] = c ("estimate", "p.value")

### Associating individual bacteria with age

tmpMat [, "age", c ("estimate", "p.value")] =
  t (apply (bacteria, MARGIN = 2, FUN = function (x)
    unlist (cor.test (phenotypes$age, x,
                      method = cor_method, use = "pairwise.complete.obs")[c ("estimate", "p.value")])))
#head(tmpMat,5)

### Sort by cluster_name and then decreasing values of kIN
output2 = cbind(tmpMat[, "age", c ("estimate", "p.value")], "p.adjust" = p.adjust (tmpMat [, "age", "p.value"], method = "BH"))
colnames (output2) = paste (rep ("age", 3), colnames (output2), sep = "_")
output3 = cbind (output, output2)
output3 = output3 [with (output3,  order (cluster_name, -kIN)), ]

### Write to file
write.table (output3, file = "./result/individual_bacteria.txt", sep = "\t", col.names = NA, quote = F, row.names = T)
rm (output, output2, output3, tmpMat, dat_tmp)



# step7_合并结果
### Create a joint data frame of bacteria cluster eigengene
### equivalents/effective abundances ('MEsMetLip')
MEsMetLip = MEsMeta [rownames (MEsMeta),]
### Rename module names (columnames) from 'colors' to numbers
colnames (MEsMetLip) = cluster_mapping_file_b [paste0 ("L_", colnames (MEsMeta)), "New_Name"]

### Save MEsMetLip to file, order by module number
write.table (MEsMetLip [ , order (colnames (MEsMetLip))], file = "./result/MEs_bacteria_clusters.txt", sep = "\t", row.names = T, col.names = NA, quote = F)



### Step 8 - Link bacteria clusters to phenotype of interest
### Analogous to Step 6.
### This is a core analysis step generating associations between the
### integrated/clustered –omics data and a clinically interesting phenotype.

cor_age <- list () ### Data structure for storing results of correlation tests under different setups

tmpMat = array (NA, c (ncol (MEsMetLip), 1, 2))
dimnames (tmpMat) [[1]] = names (MEsMetLip)
dimnames (tmpMat) [[2]] = c ("age") 
dimnames (tmpMat) [[3]] = c ("estimate", "p.value")

### Associating bacteria clusters with age     
tmpMat [, "age", c ("estimate", "p.value")] =
  t (apply (MEsMetLip, MARGIN = 2, FUN = function (x) 
    unlist (cor.test (phenotypes$age, x,
                      method = cor_method, use = "pairwise.complete.obs") [c ("estimate", "p.value")])))       

cor_age [["metlip"]] <- tmpMat
rm (tmpMat)



### Step 11 - Save phenotype associations
###
### Save the age association of bacteria clusters calculated in Step 8.
###
tmpMat = cor_age [["metlip"]]
out = cbind (tmpMat [, "age", c("estimate", "p.value")], "p.adjust" = p.adjust (tmpMat [, "age","p.value"], method = "BH"))
colnames (out) = paste (rep ("age", 3), colnames (out), sep = "_")
write.table (out, file = "./result/age_cluster_bacteria.txt", sep = "\t", row.names = T, col.names = NA, quote = F)



### Step 12 - Select features with significant differences
###
### Here, combine and integrate those functional, taxonomic and metabolomics
### features which reliably correspond to the host phenotype of interest, then
### later determine their inter-correlations.
### 此处只计算metabolomics features中P.adjust < 0.1的

final.fdr.cutoffs = 0.1 ### FDR thresholds, change to your likings.
sig_name <- list ()
sig_name [[paste ("fdr", final.fdr.cutoffs, sep = "_")]] [["metlip"]] =
  names (which (p.adjust (tmpMat [ , "age", "p.value"], method = "BH") < final.fdr.cutoffs))

#sig_name

# 将具有显著性的bacteria cluster提取出来
age_cluster_bacteria <- read.table("./result/age_cluster_bacteria.txt",sep = "\t", header = T, row.names = 1)
sig_name_bacteria <- row.names(age_cluster_bacteria)[age_cluster_bacteria$age_p.adjust < 0.1]
MEsbac <- read.table("./result/MEs_bacteria_clusters.txt",sep = "\t", header = T, row.names = 1)
MEsbac_sig <- MEsbac[,sig_name_bacteria]


### Step 13 - Correlate metabolite clusters to bacteria clusters
###
### The set of metabolite clusters associated with the phenotype of interest
### should next be tested for association with the set of bacteria
### clusters likewise so associated (identified in Step 12). 
###
### In this step, the correlations between each metabolite cluster and
### microbiota cluster are determined.
###
# 将具有显著性的metabolites cluster提取出来
# sig_name_metabolites <- row.names(out)[out[,3] < 0.1]
# MEsmeta_sig <- MEsMetLip[,sig_name_metabolites]
# 
# 
# # 将计算的相应的结果读入进来
# # 读入肠道菌cluster,提取其age_p.adjust < 0.1的行，读入肠道菌降维后的数据矩阵，并提取具有显著性的行
# 
# age_cluster_bacteria <- read.table("./result/age_cluster_bacteria.txt",sep = "\t", header = T, row.names = 1)
# sig_name_bacteria <- row.names(age_cluster_bacteria)[age_cluster_bacteria$age_p.adjust < 0.1]
# MEsbac <- read.table("./result/MEs_bacteria_clusters.txt",sep = "\t", header = T, row.names = 1)
# MEsbac_sig <- MEsbac[,sig_name_bacteria]

# metabolite cluster and microbiota cluster相关性计算
bac_MEtlip_cor = matrix (NA, nrow = ncol (MEsbac_sig), ncol = ncol (MEsmeta_sig))
dim(bac_MEtlip_cor)
rownames (bac_MEtlip_cor) = colnames (MEsbac_sig)
colnames (bac_MEtlip_cor) = colnames (MEsmeta_sig)

bac_MEtlip_p = bac_MEtlip_cor
bac_MEtlip_p.adjust = bac_MEtlip_cor

for (m in colnames (MEsmeta_sig)) {
  bac_MEtlip_cor [ , m] = apply (MEsbac_sig, MARGIN = 2, FUN = function (x) 
    cor.test (x, MEsmeta_sig[,m], method = cor_method, use = "pairwise.complete.obs")$estimate)
  bac_MEtlip_p[,m] = apply (MEsbac_sig, MARGIN = 2, FUN = function (x) 
    cor.test (x, MEsmeta_sig[,m], method = cor_method, use = "pairwise.complete.obs")$p.value)
}

bac_MEtlip_p.adjust = apply(bac_MEtlip_p, 2, FUN = function(x)
  p.adjust(x,method = "BH"))

write.csv(bac_MEtlip_cor,"./result/bac_MEtlip_cor.csv")
write.csv(bac_MEtlip_p, "./result/bac_MEtlip_p.csv")
write.csv(bac_MEtlip_p.adjust, "./result/bac_MEtlip_p.adjust.csv")

### Step 15 - Plot metabolome-microbiome functional analysis results
###
### Create visual representation of the generated results.
###

### load modified heatmap function from the gplots R-package, which allows for
### both multi-column row-sidebar and showing text within cells (here
### significance). Note this function (heatmap.3) is different from the
### 'heatmap3' R package and the heatmap.3 function in GMD package The latest
### version can be obtained from https://gist.github.com/amcdavid/5439787 We
### have tested the script with the version loaded below.
source("./r-code/heatmap_3.R")


### Select only significant associations to show in heatmap (to make it visually
### comprehensible) I.e. exclude bacteria modules and metabolite modules with not at
### least one significant association. In this example, all rows/columns are
### kept.
tmp = bac_MEtlip_p.adjust < final.fdr.cutoffs
issig = rowSums (tmp, na.rm = T)
nbac = na.omit (names (issig [issig > 0]))
length (nbac)
issig = colSums (tmp, na.rm=T)
nmetlip = na.omit (names (issig [issig > 0]))
length (nmetlip)

### create matrix for heatmap
plotmat = bac_MEtlip_cor[nbac, nmetlip]

### create matrix with significance stars
plotmat_p = bac_MEtlip_p.adjust [nbac, nmetlip] ### p-values to make stars for heatmap
stars = matrix ("", ncol = ncol (plotmat_p), nrow = nrow (plotmat_p))
rownames (stars) = rownames (plotmat_p)
colnames (stars) = colnames (plotmat_p)
for (z in 1:ncol (stars)) {
  for (j in 1:nrow (stars)) {
    if (plotmat_p [j, z] < 0.1) {
      stars [j, z] = "+"
    }
    if (plotmat_p [j, z] < 0.01) {
      stars [j, z] = "*"
    }
    if (plotmat_p [j, z] < 0.001) {
      stars [j, z] = "**"
    }
  }
}
rm (plotmat_p)

### make sidebar with phenotype associations
pheno = c ("Age")
phenobar = matrix (NA, ncol = length (pheno), nrow = length (nbac))
colnames (phenobar) = pheno
rownames (phenobar) = nbac

for (j in pheno) {
  tmp = age_cluster_bacteria$age_p.adjust
  names(tmp) = rownames(age_cluster_bacteria)
  for (k in nbac) {
    if (tmp [k] >= 0.1) {
      phenobar [k, j] = "grey"
    } else {
      if ( age_cluster_bacteria[k,"age_estimate"]> 0) {
        phenobar [k, 1] = "darkblue"
      } else if (age_cluster_bacteria[k,"age_estimate"] < 0){
        phenobar[k, 1] = "darkred"
      } else {
        phenobar[k, 1] = "white"
      }
    }
    
  }
}


### Rename column names of phenobar
colnames (phenobar) = "Age"

### Note, normally one would cluster the rows and columns in the heatmap as
### shown below but for the paper (Pedersen et al, 2016) we needed to group the
### KEGG modules by biological similarity to make a higher-level annotation for
### the figure and thus made a manual arrangement.

### cluster rows of matrix 
d = dist (plotmat)
dend = as.dendrogram (hclust (d, method = "average"))
rm (d)

### cluster columns of matrix 
d2 = dist (t (plotmat))
dend2 = as.dendrogram (hclust (d2, method = "average"))
rm (d2)

### make heatmap with all the selected KEGG modules
pdf ("./result/heatmap_bacteria_vs_metabolite_clusters_1.pdf", height = 10, width = 10)
heatmap.3 (plotmat,
           Rowv = dend, 
           Colv = dend2, 
           dendrogram = "column",
           col = rev (bluered (100)),
           symbreaks = T,
           key = T,
           symkey = T,
           keysize = 1.5,
          # lhei = c(0.6, 2),
           cellnote = stars, 
           density.info="none",
           notecol = "black",
           notecex = 1.1,
           trace = "none",
           labRow = rownames(plotmat),
           labCol = colnames(plotmat),
           RowSideColors = t (phenobar [rownames (plotmat), ]), 
           side.height.fraction = 0.35,    
           NumColSideColors = dim (phenobar) [2], 
           margins = c (10, 10),
           cexRow = 1,
           cexCol = 1
)
dev.off()
